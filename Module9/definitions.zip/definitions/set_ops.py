"""
Student: Dominic Wood
Class: CIS189
CRN: 21906
Module: 9
Topic: 1
Assignment: Python Packages 3
Date: 03/07/2023
"""

def print_set(set: set):
    for s in set:
        print(s)