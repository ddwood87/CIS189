"""
Student: Dominic Wood
Class: CIS189
CRN: 21906
Module: 9
Topic: 1
Assignment: Python Packages 2
Date: 03/07/2023
"""

def print_dict(dictionary: dict):
    for key in dictionary.keys():
        print(f'{key}, {dictionary[key]}')